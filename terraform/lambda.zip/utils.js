"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatButtons = exports.formatFields = exports.formatContext = exports.formatEvent = exports.markdownTextBlock = exports.DEFAULT_EVENT = void 0;
exports.DEFAULT_EVENT = "No event property was provided";
function markdownTextBlock(message = "", prefix = undefined) {
    return {
        type: "mrkdwn",
        text: prefix ? `${prefix}: ${message}` : message
    };
}
exports.markdownTextBlock = markdownTextBlock;
function formatEvent(event = "No event property was provided") {
    return {
        type: "section",
        text: markdownTextBlock(event, "*Event*")
    };
}
exports.formatEvent = formatEvent;
function formatContext(context = []) {
    const contextElements = context
        .filter(({ text }) => text)
        .map(({ label, text }) => markdownTextBlock(text, label));
    if (contextElements.length != 0) {
        return {
            type: "context",
            elements: contextElements
        };
    }
    return undefined;
}
exports.formatContext = formatContext;
function formatFields(fields = []) {
    const formattedFields = fields
        .filter(({ text }) => text)
        .map(({ label, text }) => markdownTextBlock(`\n${text}`, `*${label}*`));
    if (formattedFields.length > 0) {
        return {
            type: "section",
            fields: formattedFields
        };
    }
    return undefined;
}
exports.formatFields = formatFields;
function formatButtons(links = []) {
    const buttons = links
        .filter(({ url }) => url)
        .map(link => ({
        type: "button",
        text: {
            type: "plain_text",
            text: link.label,
        },
        url: link.url
    }));
    if (buttons.length > 0) {
        return {
            type: "actions",
            elements: buttons
        };
    }
    return undefined;
}
exports.formatButtons = formatButtons;
