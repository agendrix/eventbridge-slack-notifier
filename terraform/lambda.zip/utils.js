"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATUS_EMOJI = exports.RESOLVED_STATUS = exports.DEFAULT_EVENT = void 0;
exports.markdownTextBlock = markdownTextBlock;
exports.formatEvent = formatEvent;
exports.formatBody = formatBody;
exports.formatContext = formatContext;
exports.formatFields = formatFields;
exports.formatButtons = formatButtons;
exports.isChannelId = isChannelId;
exports.statusEmoji = statusEmoji;
exports.truncate = truncate;
exports.formatTimestamp = formatTimestamp;
exports.formatDuration = formatDuration;
exports.formatTransition = formatTransition;
exports.formatTimeline = formatTimeline;
exports.formatEpisodeTitle = formatEpisodeTitle;
exports.DEFAULT_EVENT = "No event property was provided";
exports.RESOLVED_STATUS = "OK";
exports.STATUS_EMOJI = {
    ALARM: ":red_circle:",
    OK: ":large_green_circle:",
    INSUFFICIENT_DATA: ":white_circle:",
};
const MAX_REASON_LENGTH = 220;
const CHANNEL_ID_PATTERN = /^[CGD][A-Z0-9]{6,}$/;
function markdownTextBlock(message = "", prefix = undefined) {
    return {
        type: "mrkdwn",
        text: prefix ? `${prefix}: ${message}` : message
    };
}
function formatEvent(event = "No event property was provided") {
    return {
        type: "section",
        text: markdownTextBlock(event, "*Event*")
    };
}
function formatBody(body = undefined) {
    if (body === null || body === void 0 ? void 0 : body.text) {
        return {
            type: "section",
            text: markdownTextBlock(`\n${body.text}`, `*${body.label}*`)
        };
    }
    return undefined;
}
function formatContext(context = []) {
    const contextElements = context
        .filter(({ text }) => text)
        .map(({ label, text }) => markdownTextBlock(text, label));
    if (contextElements.length != 0) {
        return {
            type: "context",
            elements: contextElements
        };
    }
    return undefined;
}
function formatFields(fields = []) {
    const formattedFields = fields
        .filter(({ text }) => text)
        .map(({ label, text }) => markdownTextBlock(`\n${text}`, `*${label}*`));
    if (formattedFields.length > 0) {
        return {
            type: "section",
            fields: formattedFields
        };
    }
    return undefined;
}
function formatButtons(links = []) {
    const buttons = links
        .filter(({ url }) => url)
        .map(link => ({
        type: "button",
        text: {
            type: "plain_text",
            text: link.label,
        },
        url: link.url
    }));
    if (buttons.length > 0) {
        return {
            type: "actions",
            elements: buttons
        };
    }
    return undefined;
}
function isChannelId(channel = "") {
    return CHANNEL_ID_PATTERN.test(channel);
}
function statusEmoji(status = "") {
    return exports.STATUS_EMOJI[status] || "";
}
function truncate(text, maxLength = MAX_REASON_LENGTH) {
    return text.length > maxLength ? `${text.slice(0, maxLength - 1).trimEnd()}…` : text;
}
/** Renders as the viewer's own local time, which a team spread over several regions needs. */
function formatTimestamp(at) {
    const epoch = Math.floor(new Date(at).getTime() / 1000);
    if (!isFinite(epoch))
        return at;
    const fallback = new Date(at).toISOString().substr(11, 8);
    return `<!date^${epoch}^{time_secs}|${fallback}>`;
}
function formatDuration(from, to) {
    const minutes = Math.round((new Date(to).getTime() - new Date(from).getTime()) / 60000);
    if (!isFinite(minutes) || minutes < 0)
        return "";
    if (minutes < 60)
        return `${minutes} min`;
    return `${Math.floor(minutes / 60)} h ${minutes % 60} min`;
}
function formatTransition({ status, at, reason }) {
    const details = reason ? ` — ${truncate(reason)}` : "";
    return `${statusEmoji(status)} ${formatTimestamp(at)} *${status}*${details}`;
}
function formatTimeline(transitions = []) {
    if (transitions.length === 0)
        return undefined;
    return {
        type: "section",
        text: markdownTextBlock(transitions.map(formatTransition).join("\n"))
    };
}
function formatEpisodeTitle({ event, transitions, resolved }, bold = true) {
    const last = transitions[transitions.length - 1];
    const label = resolved ? "RESOLVED" : (last === null || last === void 0 ? void 0 : last.status) || "";
    const emphasis = bold ? "*" : "";
    const duration = resolved && transitions.length > 1 ? formatDuration(transitions[0].at, last.at) : "";
    return [
        [statusEmoji(last === null || last === void 0 ? void 0 : last.status), `${emphasis}${label}${emphasis}`, `- ${event}`].filter(part => part).join(" "),
        duration,
    ]
        .filter(part => part)
        .join(" · ");
}
