"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const web_api_1 = require("@slack/web-api");
const utils_1 = require("./utils");
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const handler = async (payload) => {
    const slackClient = new web_api_1.WebClient(process.env.SLACK_ACCESS_TOKEN);
    let { context } = payload;
    const { event, fields, body, links, attachment } = payload;
    context = context || [];
    const account = await fetchAccountAlias();
    context = account ? [account, ...context] : context;
    const formattedEvent = utils_1.formatEvent(event);
    const formattedContext = utils_1.formatContext(context);
    const formattedFields = utils_1.formatFields(fields);
    const formattedBody = utils_1.formatBody(body);
    const formattedButtons = utils_1.formatButtons(links);
    const blocks = [
        formattedEvent,
        formattedContext,
        divider,
        formattedFields,
        formattedBody,
        formattedButtons
    ].filter(block => block);
    const response = await slackClient.chat.postMessage({
        channel: process.env.SLACK_CHANNEL,
        text: event,
        blocks
    });
    if (response.ok && attachment) {
        await slackClient.files.upload({
            channels: process.env.SLACK_CHANNEL,
            thread_ts: response.ts,
            content: JSON.stringify(attachment),
            filename: "attachment.json",
            initial_comment: "attachment"
        });
    }
};
async function fetchAccountAlias() {
    let accountAlias = (await new aws_sdk_1.default.IAM().listAccountAliases().promise()).AccountAliases.shift();
    return accountAlias ? { label: "Account", text: accountAlias } : undefined;
}
const divider = { type: "divider" };
exports.handler = handler;
