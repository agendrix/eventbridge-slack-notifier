"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const web_api_1 = require("@slack/web-api");
const utils_1 = require("./utils");
const client_iam_1 = require("@aws-sdk/client-iam");
const handler = async (payload) => {
    const slackClient = new web_api_1.WebClient(process.env.SLACK_ACCESS_TOKEN);
    let { context } = payload;
    const { event, fields, body, links, attachment } = payload;
    context = context || [];
    const account = await fetchAccountAlias();
    context = account ? [account, ...context] : context;
    const formattedEvent = (0, utils_1.formatEvent)(event);
    const formattedContext = (0, utils_1.formatContext)(context);
    const formattedFields = (0, utils_1.formatFields)(fields);
    const formattedBody = (0, utils_1.formatBody)(body);
    const formattedButtons = (0, utils_1.formatButtons)(links);
    const blocks = [
        formattedEvent,
        formattedContext,
        divider,
        formattedFields,
        formattedBody,
        formattedButtons
    ].filter(block => block);
    const response = await slackClient.chat.postMessage({
        channel: process.env.SLACK_CHANNEL,
        text: event,
        blocks
    });
    if (response.ok && attachment) {
        await slackClient.files.upload({
            channels: process.env.SLACK_CHANNEL,
            thread_ts: response.ts,
            content: JSON.stringify(attachment),
            filename: "attachment.json",
            initial_comment: "attachment"
        });
    }
};
async function fetchAccountAlias() {
    var _a;
    const client = new client_iam_1.IAMClient();
    const command = new client_iam_1.ListAccountAliasesCommand({});
    let accountAlias = (_a = (await client.send(command)).AccountAliases) === null || _a === void 0 ? void 0 : _a.shift();
    return accountAlias ? { label: "Account", text: accountAlias } : undefined;
}
const divider = { type: "divider" };
exports.handler = handler;
