"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EVENT_TYPE = void 0;
exports.buildTransition = buildTransition;
exports.appendTransition = appendTransition;
exports.startEpisode = startEpisode;
exports.renderEpisode = renderEpisode;
exports.notifyEpisode = notifyEpisode;
const utils_1 = require("./utils");
exports.EVENT_TYPE = "eventbridge_notifier_episode";
const HISTORY_LIMIT = 100;
const divider = { type: "divider" };
function buildTransition(payload) {
    var _a;
    return Object.assign({ status: payload.status || "", at: payload.time || new Date().toISOString() }, (((_a = payload.body) === null || _a === void 0 ? void 0 : _a.text) ? { reason: (0, utils_1.truncate)(payload.body.text) } : {}));
}
function appendTransition(episode, transition) {
    return Object.assign(Object.assign({}, episode), { transitions: [...episode.transitions, transition], resolved: transition.status === utils_1.RESOLVED_STATUS });
}
function startEpisode(payload, transition) {
    return {
        key: payload.key,
        event: payload.event,
        transitions: [transition],
        resolved: transition.status === utils_1.RESOLVED_STATUS,
    };
}
function renderEpisode(episode, payload) {
    const blocks = [
        { type: "section", text: (0, utils_1.markdownTextBlock)((0, utils_1.formatEpisodeTitle)(episode)) },
        (0, utils_1.formatContext)(payload.context),
        divider,
        (0, utils_1.formatTimeline)(episode.transitions),
        (0, utils_1.formatButtons)(payload.links),
    ].filter(block => block);
    return {
        text: (0, utils_1.formatEpisodeTitle)(episode, false),
        blocks,
        metadata: { event_type: exports.EVENT_TYPE, event_payload: episode },
    };
}
async function findOpenEpisode(client, channel, key) {
    const history = await client.conversations.history({
        channel,
        limit: HISTORY_LIMIT,
        include_all_metadata: true,
    });
    for (const message of history.messages || []) {
        const metadata = message.metadata;
        const episode = metadata === null || metadata === void 0 ? void 0 : metadata.event_payload;
        if ((metadata === null || metadata === void 0 ? void 0 : metadata.event_type) === exports.EVENT_TYPE && (episode === null || episode === void 0 ? void 0 : episode.key) === key && !episode.resolved) {
            return { ts: message.ts, episode };
        }
    }
    return undefined;
}
async function notifyEpisode(client, channel, payload) {
    if (!(0, utils_1.isChannelId)(channel)) {
        throw new Error(`A Slack channel ID is required to update messages in place, got "${channel}"`);
    }
    const transition = buildTransition(payload);
    const open = await findOpenEpisode(client, channel, payload.key);
    if (open) {
        const episode = appendTransition(open.episode, transition);
        await client.chat.update(Object.assign({ channel, ts: open.ts }, renderEpisode(episode, payload)));
        return;
    }
    await client.chat.postMessage(Object.assign({ channel }, renderEpisode(startEpisode(payload, transition), payload)));
}
